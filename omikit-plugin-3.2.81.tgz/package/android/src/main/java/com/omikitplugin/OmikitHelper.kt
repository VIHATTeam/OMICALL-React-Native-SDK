package com.omikitplugin

import android.app.Activity
import android.app.Application
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.util.Log
import android.view.WindowManager
import androidx.annotation.RequiresApi
import com.facebook.react.ReactActivity
import com.facebook.react.ReactApplication
import com.facebook.react.ReactInstanceManager
import com.facebook.react.ReactNativeHost
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.ReactMarker
import com.facebook.react.modules.core.DeviceEventManagerModule
import com.facebook.react.shell.MainReactPackage
import com.facebook.soloader.SoLoader

/**
 * Helper class giúp đơn giản hóa việc tích hợp Omicall SDK vào ứng dụng React Native
 */
object OmikitHelper {
    private const val TAG = "OmikitHelper"
    const val ACTION_IS_INCOMING_CALL = "isIncomingCall"
    
    // Biến lưu trạng thái WakeLock
    private var wakeLock: PowerManager.WakeLock? = null
    
    /**
     * Khởi tạo cho MainApplication
     * Chỉ cần gọi hàm này trong onCreate() của MainApplication
     */
    fun initializeApp(application: Application) {
        Log.d(TAG, "Khởi tạo OmikitHelper cho Application")
        
        // Theo dõi quá trình khởi tạo React Native
        ReactMarker.setLogTag("OmicallSDK")
        
        // Đảm bảo SoLoader được khởi tạo đúng cách
        SoLoader.init(application, false)
    }
    
    /**
     * Xử lý onCreate trong MainActivity
     * Chỉ cần gọi hàm này trong onCreate() của MainActivity
     */
    fun handleCreate(activity: ReactActivity, savedInstanceState: Bundle?) {
        Log.d(TAG, "Xử lý onCreate cho Activity")
        
        // Kiểm tra intent cuộc gọi đến
        if (activity.intent?.getBooleanExtra(ACTION_IS_INCOMING_CALL, false) == true) {
            wakeLockAndShowWhenLocked(activity)
            
            // Đăng ký xử lý khi ReactContext sẵn sàng
            val reactManager = activity.reactNativeHost.reactInstanceManager
            reactManager.addReactInstanceEventListener(object : ReactInstanceManager.ReactInstanceEventListener {
                override fun onReactContextInitialized(context: ReactContext) {
                    handleIncomingCall(activity, activity.intent)
                    reactManager.removeReactInstanceEventListener(this)
                }
            })
        }
    }
    
    /**
     * Xử lý onNewIntent trong MainActivity 
     * Chỉ cần gọi hàm này trong onNewIntent() của MainActivity
     */
    fun handleNewIntent(activity: ReactActivity, intent: Intent?) {
        if (intent?.getBooleanExtra(ACTION_IS_INCOMING_CALL, false) == true) {
            activity.intent = intent
            handleIncomingCall(activity, intent)
        }
    }
    
    /**
     * Xử lý onResume trong MainActivity
     * Chỉ cần gọi hàm này trong onResume() của MainActivity
     */
    fun handleResume(activity: ReactActivity) {
        // Kích hoạt WakeLock nếu đang có cuộc gọi
        if (activity.intent?.getBooleanExtra(ACTION_IS_INCOMING_CALL, false) == true) {
            wakeLockAndShowWhenLocked(activity)
        }
        
        // Khởi động lại OmiClient
        OmikitPluginModule.onResume(activity)
    }
    
    /**
     * Xử lý onDestroy trong MainActivity
     * Chỉ cần gọi hàm này trong onDestroy() của MainActivity
     */
    fun handleDestroy() {
        releaseWakeLock()
        OmikitPluginModule.onDestroy()
    }
    
    /**
     * Xử lý onRequestPermissionsResult trong MainActivity
     * Chỉ cần gọi hàm này trong onRequestPermissionsResult() của MainActivity
     */
    fun handleRequestPermissionsResult(
        activity: ReactActivity,
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        OmikitPluginModule.onRequestPermissionsResult(
            requestCode, permissions, grantResults, activity
        )
    }
    
    /**
     * Xử lý cuộc gọi đến
     */
    private fun handleIncomingCall(activity: ReactActivity, intent: Intent) {
        Log.d(TAG, "Xử lý cuộc gọi đến: $intent")
        
        // Đảm bảo màn hình được bật
        wakeLockAndShowWhenLocked(activity)
        
        // Xử lý cuộc gọi thông qua OmikitPluginModule
        try {
            val reactContext = activity.reactNativeHost.reactInstanceManager.currentReactContext 
                as? ReactApplicationContext
                
            if (reactContext != null) {
                OmikitPluginModule.onGetIntentFromNotification(reactContext, intent, activity)
            } else {
                Log.w(TAG, "React context chưa sẵn sàng, sẽ xử lý khi context được khởi tạo")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi xử lý cuộc gọi: ${e.message}", e)
        }
    }
    
    /**
     * Hiển thị màn hình khi khóa và giữ màn hình luôn sáng
     */
    private fun wakeLockAndShowWhenLocked(activity: Activity) {
        try {
            // Hiển thị trên màn hình khóa
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                activity.setShowWhenLocked(true)
                activity.setTurnScreenOn(true)
                val keyguardManager = activity.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                keyguardManager.requestDismissKeyguard(activity, null)
            } else {
                @Suppress("DEPRECATION")
                activity.window.addFlags(
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                )
            }
            
            // Tạo WakeLock nếu cần
            if (wakeLock == null || wakeLock?.isHeld != true) {
                val powerManager = activity.getSystemService(Context.POWER_SERVICE) as PowerManager
                wakeLock = powerManager.newWakeLock(
                    PowerManager.FULL_WAKE_LOCK or 
                    PowerManager.ACQUIRE_CAUSES_WAKEUP or
                    PowerManager.ON_AFTER_RELEASE,
                    "OmikitPlugin:CallWakeLock"
                )
                wakeLock?.acquire(10*60*1000L) // 10 phút
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi khi thiết lập màn hình: ${e.message}", e)
        }
    }
    
    /**
     * Giải phóng WakeLock
     */
    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
                wakeLock = null
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi giải phóng WakeLock: ${e.message}", e)
        }
    }
    
    /**
     * Đảm bảo các module cần thiết được đăng ký
     */
    fun ensureRequiredPackages(packages: MutableList<com.facebook.react.ReactPackage>): List<com.facebook.react.ReactPackage> {
        // Đảm bảo MainReactPackage được thêm vào
        if (packages.none { it is MainReactPackage }) {
            packages.add(MainReactPackage())
            Log.d(TAG, "Thêm MainReactPackage để cung cấp các module cơ bản")
        }
        
        return packages
    }
} 