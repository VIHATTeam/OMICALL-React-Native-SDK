package com.omikitplugin

import android.app.Application
import android.util.Log
import com.facebook.react.PackageList
import com.facebook.react.ReactApplication
import com.facebook.react.ReactHost
import com.facebook.react.ReactNativeHost
import com.facebook.react.ReactPackage
import com.facebook.react.defaults.DefaultNewArchitectureEntryPoint
import com.facebook.react.defaults.DefaultReactHost
import com.facebook.react.defaults.DefaultReactNativeHost
import com.facebook.soloader.SoLoader
import com.facebook.react.shell.MainReactPackage

/**
 * OmicallApplication - Base Application class với tất cả tính năng của Omicall SDK được tích hợp sẵn
 * 
 * Hướng dẫn sử dụng đơn giản:
 * 1. Kế thừa OmicallApplication thay vì Application và implement ReactApplication
 * 2. Override getMainComponentName() để trả về tên component chính của ứng dụng
 * 
 * Ví dụ:
 * ```
 * class MainApplication : OmicallApplication() {
 *     override fun getMainComponentName(): String = "MyApp"
 * }
 * ```
 */
abstract class OmicallApplication : Application(), ReactApplication {

    private val TAG = "OmicallApplication"
    
    /**
     * Override phương thức này để đặt tên component chính của ứng dụng
     */
    abstract fun getMainComponentName(): String
    
    /**
     * Override phương thức này để cung cấp các package bổ sung (nếu cần)
     */
    open fun getAdditionalReactPackages(): List<ReactPackage> {
        return emptyList()
    }
    
    /**
     * Cấu hình mặc định cho ReactNativeHost
     */
    override val reactNativeHost: ReactNativeHost = object : DefaultReactNativeHost(this) {
        override fun getPackages(): List<ReactPackage> {
            val packageList = PackageList(this).packages.toMutableList()
            
            // Thêm các package bổ sung từ ứng dụng
            packageList.addAll(getAdditionalReactPackages())
            
            // Đảm bảo các package cần thiết cho Omicall
            return OmikitHelper.ensureRequiredPackages(packageList)
        }

        override fun getJSMainModuleName(): String = "index"
        
        override fun getMainModuleName(): String = getMainComponentName()

        override fun getUseDeveloperSupport(): Boolean = BuildConfig.DEBUG

        override val isNewArchEnabled: Boolean = BuildConfig.IS_NEW_ARCHITECTURE_ENABLED
        override val isHermesEnabled: Boolean = BuildConfig.IS_HERMES_ENABLED
    }

    /**
     * Cấu hình mặc định cho ReactHost
     */
    override val reactHost: ReactHost
        get() = DefaultReactHost.getDefaultReactHost(applicationContext, reactNativeHost)

    /**
     * Khởi tạo ứng dụng với các cấu hình cần thiết cho Omicall SDK
     */
    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "onCreate: Khởi tạo OmicallApplication")
        
        // Khởi tạo Omicall SDK
        OmikitHelper.initializeApp(this)
        
        // Khởi tạo React Native
        if (BuildConfig.IS_NEW_ARCHITECTURE_ENABLED) {
            DefaultNewArchitectureEntryPoint.load()
        }
    }
} 