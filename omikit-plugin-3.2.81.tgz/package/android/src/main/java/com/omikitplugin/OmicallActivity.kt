package com.omikitplugin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.facebook.react.ReactActivity
import com.facebook.react.ReactActivityDelegate
import com.facebook.react.defaults.DefaultReactActivityDelegate

/**
 * OmicallActivity - Base Activity class với tất cả tính năng của Omicall SDK được tích hợp sẵn
 * 
 * Hướng dẫn sử dụng đơn giản:
 * 1. Kế thừa OmicallActivity thay vì ReactActivity
 * 2. Override getMainComponentName() để trả về tên component chính của ứng dụng
 * 
 * Ví dụ:
 * ```
 * class MainActivity : OmicallActivity() {
 *     override fun getMainComponentName(): String = "MyApp"
 * }
 * ```
 */
abstract class OmicallActivity : ReactActivity() {
    
    private val TAG = "OmicallActivity"
    
    /**
     * Override phương thức này để đặt tên component chính của ứng dụng
     */
    abstract override fun getMainComponentName(): String
    
    /**
     * Phương thức này đã được cấu hình sẵn để sử dụng với Omicall SDK
     * Mặc định sử dụng DefaultReactActivityDelegate với New Architecture được bật
     */
    override fun createReactActivityDelegate(): ReactActivityDelegate {
        return DefaultReactActivityDelegate(this, mainComponentName, true)
    }
    
    /**
     * Phương thức này tự động xử lý logic cuộc gọi đến khi Activity được tạo
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d(TAG, "onCreate: Khởi tạo OmicallActivity")
        OmikitHelper.handleCreate(this, savedInstanceState)
    }
    
    /**
     * Phương thức này tự động xử lý khi có Intent mới đến
     */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        Log.d(TAG, "onNewIntent: Xử lý intent mới")
        OmikitHelper.handleNewIntent(this, intent)
    }
    
    /**
     * Phương thức này tự động xử lý khi Activity được resume
     */
    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume: Khởi động lại OmiClient")
        OmikitHelper.handleResume(this)
    }
    
    /**
     * Phương thức này tự động xử lý khi Activity bị hủy
     */
    override fun onDestroy() {
        Log.d(TAG, "onDestroy: Giải phóng tài nguyên")
        OmikitHelper.handleDestroy()
        super.onDestroy()
    }
    
    /**
     * Phương thức này tự động xử lý kết quả từ yêu cầu quyền
     */
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        Log.d(TAG, "onRequestPermissionsResult: Xử lý kết quả quyền")
        OmikitHelper.handleRequestPermissionsResult(this, requestCode, permissions, grantResults)
    }
} 