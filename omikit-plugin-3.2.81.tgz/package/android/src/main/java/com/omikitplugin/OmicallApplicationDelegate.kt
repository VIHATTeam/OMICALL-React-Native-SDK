package com.omikitplugin

import android.app.Application
import android.util.Log
import com.facebook.react.ReactPackage
import com.facebook.react.shell.MainReactPackage

/**
 * OmicallApplicationDelegate - Delegate class quản lý tính năng Omicall SDK trong Application
 * 
 * Hướng dẫn sử dụng đơn giản:
 * 1. Tạo một instance của OmicallApplicationDelegate trong MainApplication
 * 2. Gọi các phương thức tương ứng trong onCreate và getPackages
 * 
 * Ví dụ:
 * ```
 * class MainApplication : Application(), ReactApplication {
 *     private val omicallDelegate = OmicallApplicationDelegate(this)
 *     
 *     override fun onCreate() {
 *         super.onCreate()
 *         omicallDelegate.initialize()
 *     }
 *     
 *     override val reactNativeHost = object : DefaultReactNativeHost(this) {
 *         override fun getPackages(): List<ReactPackage> {
 *             val packages = PackageList(this).packages.toMutableList()
 *             // Thêm các package khác (nếu cần)
 *             return omicallDelegate.setupReactPackages(packages)
 *         }
 *         // Các phương thức khác...
 *     }
 * }
 * ```
 */
class OmicallApplicationDelegate(private val application: Application) {
    
    private val TAG = "OmicallApplicationDelegate"
    
    /**
     * Khởi tạo Omicall SDK trong ứng dụng.
     * Gọi trong onCreate() của Application.
     */
    fun initialize() {
        Log.d(TAG, "initialize: Khởi tạo Omicall cho Application")
        OmikitHelper.initializeApp(application)
    }
    
    /**
     * Đảm bảo các package cần thiết cho Omicall đã được thêm vào danh sách.
     * Gọi trong getPackages() của ReactNativeHost.
     */
    fun setupReactPackages(packages: MutableList<ReactPackage>): List<ReactPackage> {
        Log.d(TAG, "setupReactPackages: Đảm bảo các package cần thiết cho Omicall")
        return OmikitHelper.ensureRequiredPackages(packages)
    }
} 