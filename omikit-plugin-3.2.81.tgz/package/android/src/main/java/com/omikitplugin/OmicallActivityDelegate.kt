package com.omikitplugin

import android.content.Intent
import android.os.Bundle
import android.util.Log
import com.facebook.react.ReactActivity

/**
 * OmicallActivityDelegate - Delegate class quản lý tính năng Omicall SDK trong Activity
 * 
 * Hướng dẫn sử dụng đơn giản:
 * 1. Tạo một instance của OmicallActivityDelegate trong MainActivity
 * 2. Gọi các phương thức tương ứng trong các vòng đời của Activity
 * 
 * Ví dụ cho React Native 0.78+:
 * ```
 * class MainActivity : ReactActivity() {
 *     private val omicallDelegate = OmicallActivityDelegate(this)
 *     
 *     override fun createReactActivityDelegate(): ReactActivityDelegate {
 *         return DefaultReactActivityDelegate(this, "YourAppName")
 *     }
 *     
 *     override fun onCreate(savedInstanceState: Bundle?) {
 *         super.onCreate(savedInstanceState)
 *         omicallDelegate.onCreate(savedInstanceState)
 *     }
 *     
 *     // Các phương thức khác...
 * }
 * ```
 */
class OmicallActivityDelegate(private val activity: ReactActivity) {
    
    private val TAG = "OmicallActivityDelegate"
    
    /**
     * Phương thức này xử lý logic cuộc gọi đến khi Activity được tạo.
     * Gọi trong onCreate() của Activity.
     */
    fun onCreate(savedInstanceState: Bundle?) {
        Log.d(TAG, "onCreate: Khởi tạo Omicall cho Activity")
        OmikitHelper.handleCreate(activity, savedInstanceState)
    }
    
    /**
     * Phương thức này xử lý khi có Intent mới đến.
     * Gọi trong onNewIntent() của Activity.
     */
    fun onNewIntent(intent: Intent?) {
        Log.d(TAG, "onNewIntent: Xử lý intent mới")
        OmikitHelper.handleNewIntent(activity, intent)
    }
    
    /**
     * Phương thức này xử lý khi Activity được resume.
     * Gọi trong onResume() của Activity.
     */
    fun onResume() {
        Log.d(TAG, "onResume: Khởi động lại OmiClient")
        OmikitHelper.handleResume(activity)
    }
    
    /**
     * Phương thức này xử lý khi Activity bị hủy.
     * Gọi trong onDestroy() của Activity.
     */
    fun onDestroy() {
        Log.d(TAG, "onDestroy: Giải phóng tài nguyên")
        OmikitHelper.handleDestroy()
    }
    
    /**
     * Phương thức này xử lý kết quả từ yêu cầu quyền.
     * Gọi trong onRequestPermissionsResult() của Activity.
     */
    fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        Log.d(TAG, "onRequestPermissionsResult: Xử lý kết quả quyền")
        OmikitHelper.handleRequestPermissionsResult(activity, requestCode, permissions, grantResults)
    }
} 