package com.omikitplugin

import android.app.Activity
import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.util.Log
import android.view.WindowManager
import com.facebook.react.ReactActivity
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContext
import com.facebook.react.bridge.WritableMap
import com.facebook.react.bridge.WritableNativeMap
import vn.vihat.omicall.omisdk.OmiClient
import vn.vihat.omicall.omisdk.service.NotificationService
import vn.vihat.omicall.omisdk.utils.SipServiceConstants
import vn.vihat.omicall.omisdk.utils.Utils
import java.lang.ref.WeakReference

/**
 * OmicallCallHandler - Xử lý cuộc gọi đến một cách đáng tin cậy hơn
 * khi ứng dụng bị kill hoặc React Context chưa khởi tạo xong
 */
class OmicallCallHandler {
    companion object {
        private const val TAG = "OmicallCallHandler"
        private const val MAX_RETRIES = 10
        private const val RETRY_DELAY_MS = 500L
        
        // Dùng WeakReference để tránh memory leak
        private var pendingCallContexts = mutableListOf<WeakReference<Context>>()
        private var pendingCallIntents = mutableListOf<Intent>()
        private var retryCount = 0
        private var wakeLock: PowerManager.WakeLock? = null
        
        /**
         * Xử lý cuộc gọi đến - điểm vào chính khi có cuộc gọi
         */
        fun handleIncomingCall(context: Context, intent: Intent) {
            Log.d(TAG, "handleIncomingCall: context=$context, intent=$intent")
            
            // Đảm bảo màn hình được bật khi có cuộc gọi
            ensureScreenOn(context)
            
            try {
                val isIncoming = intent.getBooleanExtra(SipServiceConstants.ACTION_IS_INCOMING_CALL, false)
                if (!isIncoming) return
                
                if (context is Activity) {
                    // Đảm bảo activity hiển thị trên màn hình khóa
                    ensureActivityVisible(context)
                }
                
                // Cố gắng tìm React Context đã được khởi tạo
                val reactContext = getCurrentReactContext(context)
                if (reactContext != null) {
                    Log.d(TAG, "React context available, handling call directly")
                    processCall(reactContext, intent, context)
                } else {
                    // Lưu lại để xử lý sau khi React Context được khởi tạo
                    Log.d(TAG, "React context not ready, queuing call for later")
                    pendingCallContexts.add(WeakReference(context))
                    pendingCallIntents.add(intent)
                    retryCount = 0
                    
                    // Bắt đầu retry
                    Handler(Looper.getMainLooper()).postDelayed({ 
                        tryProcessPendingCalls() 
                    }, RETRY_DELAY_MS)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error handling incoming call: ${e.message}", e)
            }
        }
        
        /**
         * Thử xử lý lại các cuộc gọi đang chờ
         */
        private fun tryProcessPendingCalls() {
            if (pendingCallIntents.isEmpty()) return
            
            // Tìm context hợp lệ
            val validContexts = pendingCallContexts
                .mapNotNull { it.get() }
                .toMutableList()
            
            // Cập nhật lại danh sách context còn hợp lệ
            pendingCallContexts.clear()
            validContexts.forEach { pendingCallContexts.add(WeakReference(it)) }
            
            if (validContexts.isEmpty()) {
                Log.d(TAG, "No valid contexts left, clearing pending calls")
                pendingCallIntents.clear()
                return
            }
            
            // Lấy context đầu tiên
            val context = validContexts[0]
            val reactContext = getCurrentReactContext(context)
            
            if (reactContext != null) {
                Log.d(TAG, "React context now available, processing ${pendingCallIntents.size} pending calls")
                
                // Xử lý tất cả các cuộc gọi đang chờ
                val intents = pendingCallIntents.toList()
                pendingCallIntents.clear()
                
                intents.forEach { intent ->
                    processCall(reactContext, intent, context)
                }
                
                pendingCallContexts.clear()
            } else if (retryCount < MAX_RETRIES) {
                // Thử lại sau
                retryCount++
                Log.d(TAG, "React context still not ready, retrying ($retryCount/$MAX_RETRIES)...")
                Handler(Looper.getMainLooper()).postDelayed({ 
                    tryProcessPendingCalls() 
                }, RETRY_DELAY_MS)
            } else {
                Log.e(TAG, "Failed to process calls after $MAX_RETRIES retries")
                
                // Thử sử dụng OmiClient trực tiếp nếu có thể
                try {
                    if (context is ReactActivity) {
                        OmiClient.getInstance(context)
                        OmiClient.isAppReady = true
                        
                        // Thử một lần nữa
                        Handler(Looper.getMainLooper()).postDelayed({
                            val newReactContext = getCurrentReactContext(context)
                            if (newReactContext != null) {
                                val intents = pendingCallIntents.toList()
                                pendingCallIntents.clear()
                                pendingCallContexts.clear()
                                
                                intents.forEach { intent ->
                                    processCall(newReactContext, intent, context)
                                }
                            }
                        }, 1000L)
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to initialize OmiClient directly: ${e.message}", e)
                }
            }
        }
        
        /**
         * Xử lý cuộc gọi khi đã có React Context
         */
        private fun processCall(reactContext: ReactContext, intent: Intent, context: Context) {
            try {
                if (context is ReactActivity) {
                    OmikitPluginModule.onGetIntentFromNotification(
                        reactContext as ReactApplicationContext,
                        intent,
                        context
                    )
                    Log.d(TAG, "Call processed successfully")
                } else {
                    Log.e(TAG, "Context is not ReactActivity, can't process call")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error processing call: ${e.message}", e)
            }
        }
        
        /**
         * Lấy ReactContext hiện tại nếu đã được khởi tạo
         */
        private fun getCurrentReactContext(context: Context): ReactContext? {
            return try {
                if (context is ReactActivity) {
                    val reactActivity = context
                    val reactNativeHost = reactActivity.reactNativeHost
                    val reactInstanceManager = reactNativeHost.reactInstanceManager
                    reactInstanceManager.currentReactContext
                } else {
                    null
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error getting React context: ${e.message}", e)
                null
            }
        }
        
        /**
         * Đảm bảo màn hình sáng khi có cuộc gọi
         */
        private fun ensureScreenOn(context: Context) {
            try {
                // Tạo WakeLock nếu cần
                if (wakeLock == null || wakeLock?.isHeld != true) {
                    val powerManager = context.getSystemService(Context.POWER_SERVICE) as PowerManager
                    wakeLock = powerManager.newWakeLock(
                        PowerManager.FULL_WAKE_LOCK or
                        PowerManager.ACQUIRE_CAUSES_WAKEUP or
                        PowerManager.ON_AFTER_RELEASE,
                        "OmikitPlugin:CallWakeLock"
                    )
                    wakeLock?.acquire(10*60*1000L) // 10 phút
                    Log.d(TAG, "WakeLock acquired")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to acquire wake lock: ${e.message}", e)
            }
        }
        
        /**
         * Đảm bảo activity được hiển thị trên màn hình khóa
         */
        private fun ensureActivityVisible(activity: Activity) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
                    activity.setShowWhenLocked(true)
                    activity.setTurnScreenOn(true)
                    
                    val keyguardManager = activity.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
                    keyguardManager.requestDismissKeyguard(activity, null)
                } else {
                    @Suppress("DEPRECATION")
                    activity.window.addFlags(
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                    )
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error ensuring activity visible: ${e.message}", e)
            }
        }
        
        /**
         * Giải phóng WakeLock
         */
        fun releaseWakeLock() {
            try {
                if (wakeLock != null && wakeLock?.isHeld == true) {
                    wakeLock?.release()
                    wakeLock = null
                    Log.d(TAG, "WakeLock released")
                }
            } catch (e: Exception) {
                Log.e(TAG, "Failed to release wake lock: ${e.message}", e)
            }
        }
    }
} 